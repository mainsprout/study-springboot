package com.example.board.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Builder
@AllArgsConstructor
@Getter
@ToString(exclude = "writer") // writer는 문자열에서 제외
@NoArgsConstructor
public class Board extends BaseEntity {
    // Member의 이메일(PK)을 FK로 참조하는 구조

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 기본키 자동생성
    private Long bno;

    private String title;

    private String content;

    @ManyToOne(fetch = FetchType.LAZY) // Lazy Loading 사용
    private Member writer; // 연관 관계 지정

    public void changeTitle(String title){
        this.title = title;
    }

    public void changeContent(String content){
        this.content = content;
    }
}