package com.example.board.repository.search;

import com.example.board.entity.Board;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface SearchBoardRepository {
    Board search1();

    // DTO를 가능하면 Repository 영역에서 다루지 않게 하기 위해 각각 저장.
    Page<Object[]> searchPage(String type, String keyword, Pageable pageable);
}
